"""controller.py

Connects the PySide UI with Blender.

The Controller is the single owner of the current picker's data. It holds
that data (for whichever armature is active) in memory as plain Python
dicts/lists, and is responsible for saving/loading it through the JSON
Manager. Blender's Scene is never used for storage.
"""

import os
import tempfile

import bpy

from .. import json_manager
from .. import backend

IK_FK_GROUPS = {

    "upper_arm_parent.L": {
        "output_bones": [
            "upper_arm_fk.L",
            "forearm_fk.L",
            "hand_fk.L",
        ],
        "input_bones": [
            "upper_arm_ik.L",
            "MCH-forearm_ik.L",
            "MCH-upper_arm_ik_target.L",
        ],
        "ctrl_bones": [
            "upper_arm_ik.L",
            "upper_arm_ik_target.L",
            "hand_ik.L",
        ],
    },

    "upper_arm_parent.R": {
        "output_bones": [
            "upper_arm_fk.R",
            "forearm_fk.R",
            "hand_fk.R",
        ],
        "input_bones": [
            "upper_arm_ik.R",
            "MCH-forearm_ik.R",
            "MCH-upper_arm_ik_target.R",
        ],
        "ctrl_bones": [
            "upper_arm_ik.R",
            "upper_arm_ik_target.R",
            "hand_ik.R",
        ],
    },
    "thigh_parent.L": {
        "output_bones": [
            "thigh_fk.L",
            "shin_fk.L",
            "foot_fk.L",
            "toe_fk.L",
        ],
        "input_bones": [
            "thigh_ik.L",
            "MCH-shin_ik.L",
            "MCH-thigh_ik_target.L",
        ],
        "ctrl_bones": [
            "thigh_ik.L",
            "thigh_ik_target.L",
            "foot_ik.L",
        ],

        "tail_bones": [
            "toe_ik.L",
        ],

        "extra_ctrls": [
            "foot_heel_ik.L",
            "foot_spin_ik.L",
        ],

        "heel_control": "foot_heel_ik.L",
    },
    "thigh_parent.R": {
        "output_bones": [
            "thigh_fk.R",
            "shin_fk.R",
            "foot_fk.R",
            "toe_fk.R",
        ],

        "input_bones": [
            "thigh_ik.R",
            "MCH-shin_ik.R",
            "MCH-thigh_ik_target.R",
        ],

        "ctrl_bones": [
            "thigh_ik.R",
            "thigh_ik_target.R",
            "foot_ik.R",
        ],

        "tail_bones": [
            "toe_ik.R",
        ],

        "extra_ctrls": [
            "foot_heel_ik.R",
            "foot_spin_ik.R",
        ],

        "heel_control": "foot_heel_ik.R",
    },
}


class Controller:

    def __init__(self):
        self.window = None
        self.selected_bones = set()
        self.active = False

        # Name of the armature the currently-loaded data belongs to.
        self.armature_name = None

        # In-memory picker data for the current armature:
        # {"background": str, "symmetry": bool, "symmetry_x": float, "items": [...]}
        self.data = json_manager.new_armature_data()

    # ---------------------------------------------------------

    def set_window(self, window):
        self.window = window

    # ---------------------------------------------------------
    # ARMATURE SWITCHING
    # ---------------------------------------------------------

    def load_armature(self, rig):
        """Saves the current picker to JSON, then loads the given armature's
        picker (or a blank one) from JSON and refreshes the UI."""

        # Persist whatever is currently loaded before switching away from it.
        self.save()

        self.selected_bones = set()

        if rig is None:
            self.armature_name = None
            self.data = json_manager.new_armature_data()
        else:
            self.armature_name = rig.name
            stored = json_manager.get_armature_data(rig.name)
            self.data = stored if stored is not None else json_manager.new_armature_data()

        self.refresh()

        if self.window is not None:
            self.window.size_combo.setEnabled(False)
            self.window.shape_combo.setEnabled(False)
            self.window.color_combo.setEnabled(False)

            # Keep the dropdown's displayed text in sync when the active
            # armature changes from outside the combo itself (e.g. clicking
            # a different rig in the 3D viewport, detected by
            # backend.poll_active_armature). Block signals while setting it
            # so this doesn't re-trigger change_armature() and recurse back
            # into load_armature().
            combo = self.window.armature_combo
            target_text = self.armature_name or ""
            if combo.currentText() != target_text:
                combo.blockSignals(True)
                index = combo.findText(target_text)
                if index >= 0:
                    combo.setCurrentIndex(index)
                combo.blockSignals(False)

    def change_armature(self, armature_name):
        rig = bpy.data.objects.get(armature_name)
        if rig is None or rig.type != "ARMATURE":
            return

        backend._CACHED_ARM = rig
        backend._CACHED_ARM_NAME = rig.name

        view_layer = bpy.context.view_layer
        for obj in view_layer.objects:
            if obj != rig and obj.select_get():
                obj.select_set(False)

        view_layer.objects.active = rig
        rig.select_set(True)

        self.load_armature(rig)


    def save(self):
        """Writes the current in-memory data to rig_picker_data.json."""
        if self.armature_name:
            json_manager.save_armature_data(self.armature_name, self.data)

    def find_item(self, bone_name):
        return next(
            (item for item in self.data["items"] if item["bone_name"] == bone_name),
            None,
        )

    def refresh_ikfk_label(self):
        """Updates the IK/FK toggle button to show the state it will
        switch TO if clicked (e.g. "->IK" while currently in FK), based
        on the currently selected bone's live IK_FK property. Shows a
        neutral label when there's no single selected bone that belongs
        to an IK/FK group.
        """
        if self.window is None:
            return

        is_fk = None

        if len(self.selected_bones) == 1:
            selected_bone = next(iter(self.selected_bones))

            for parent, group in IK_FK_GROUPS.items():
                if (
                    selected_bone == parent
                    or selected_bone in group["output_bones"]
                    or selected_bone in group["input_bones"]
                    or selected_bone in group["ctrl_bones"]
                ):
                    rig = backend.arm()

                    if rig is not None:
                        pb = rig.pose.bones.get(parent)

                        if pb is not None and "IK_FK" in pb:
                            # Rigify convention: 0.0 = IK, 1.0 = FK
                            is_fk = float(pb["IK_FK"]) >= 0.5

                    break

        self.window.control_list.container.update_ikfk_toggle(is_fk)

    # ---------------------------------------------------------

    def refresh(self):
        if self.window is None:
            return

        self.window.control_list.clear_controls()

        canvas = self.window.control_list.container

        if self.data.get("background"):
            self.window.control_list.set_background(
                self.data["background"],
                self.data.get("image_offset_x", 0.0),
                self.data.get("image_offset_y", 0.0),
            )
        else:
            self.window.control_list.clear_background()

        canvas.symmetry_enabled = self.data.get("symmetry", False)
        canvas.symmetry_x = self.data.get("symmetry_x", -1.0)

        # Sync the checkbox to match the loaded armature's stored value.
        # blockSignals() prevents this from re-triggering toggle_symmetry(),
        # which would otherwise immediately re-save the value we just loaded
        # (harmless, but pointless) and could clobber symmetry_x if the
        # background isn't set up yet.
        self.window.symmetry_checkbox.blockSignals(True)
        self.window.symmetry_checkbox.setChecked(
            self.data.get("symmetry", False)
        )
        self.window.symmetry_checkbox.blockSignals(False)

        self.window.ik_fk_checkbox.blockSignals(True)
        self.window.ik_fk_checkbox.setChecked(
            self.data.get("ik_fk_enabled", False)
        )
        self.window.ik_fk_checkbox.blockSignals(False)

        canvas.ikfk_controls_enabled = self.data.get("ik_fk_enabled", False)

        self.window.motion_paths_checkbox.blockSignals(True)
        self.window.motion_paths_checkbox.setChecked(
            self.data.get("motion_paths_enabled", False)
        )
        self.window.motion_paths_checkbox.blockSignals(False)

        canvas.motion_paths_controls_enabled = self.data.get("motion_paths_enabled", False)
        canvas.update_overlay_buttons()

        for item in self.data["items"]:
            x = None if item["x"] < 0 else item["x"]
            y = None if item["y"] < 0 else item["y"]

            self.window.control_list.add_control(
                item["bone_name"],
                x,
                y,
                item.get("control_size", 36),
                item.get("control_shape", "CIRCLE"),
                item.get("control_color", "GREEN"),
            )

            widget = self.window.control_list.controls[item["bone_name"]]
            self.window.connect_item(widget)

        self.window.control_list.container.layout_controls()
        self.window.control_list.container.update()

        self.refresh_ikfk_label()

    # ---------------------------------------------------------

    def add_selected(self):
        from ..backend import arm, mirror_name

        rig = arm()
        if not rig:
            return

        existing = {item["bone_name"] for item in self.data["items"]}

        for pb in rig.pose.bones:
            if not pb.select or pb.name in existing:
                continue

            new_item = {
                "bone_name": pb.name,
                "label": pb.name,
                "x": -1.0,
                "y": -1.0,
                "control_size": 36,
                "control_shape": "CIRCLE",
                "control_color": "GREEN",
            }

            mirror = mirror_name(pb.name)

            if self.data.get("symmetry") and mirror is not None:
                mirror_item = self.find_item(mirror)

                if mirror_item and mirror_item["x"] >= 0 and mirror_item["y"] >= 0:

                    # Copy appearance first
                    new_item["control_size"] = mirror_item["control_size"]
                    new_item["control_shape"] = mirror_item["control_shape"]
                    new_item["control_color"] = mirror_item["control_color"]

                    size = new_item["control_size"]

                    if new_item["control_shape"] == "RECTANGLE":
                        width = max(14, round(size * 1.6))
                    else:
                        width = size

                    mirror_center = mirror_item["x"] + width / 2.0
                    new_center = 2.0 * self.data["symmetry_x"] - mirror_center

                    new_item["x"] = new_center - width / 2.0
                    new_item["y"] = mirror_item["y"]

            self.data["items"].append(new_item)

        self.save()
        self.refresh()
    # ---------------------------------------------------------

    def select_control(self, bone_name, shift=False):
        if shift:
            if bone_name in self.selected_bones:
                self.selected_bones.remove(bone_name)
            else:
                self.selected_bones.add(bone_name)
        else:
            self.selected_bones = {bone_name}

        for name, widget in self.window.control_list.controls.items():
            widget.active = (name in self.selected_bones)
            widget.update()

        # Update UI comboboxes to match selected control appearance
        item = self.find_item(bone_name)

        if item:
            self.window.set_selected_control(
                item["control_size"],
                item["control_shape"],
                item["control_color"],
            )

        bpy.ops.rp.select(
            bone_name=bone_name,
            shift=shift
        )

        self.refresh_ikfk_label()

    def set_selected_size(self, size):
        self._set_selected_appearance(size=size)

    def set_selected_shape(self, shape):
        self._set_selected_appearance(shape=shape)

    def set_selected_color(self, color):
        self._set_selected_appearance(color=color)

    def _set_selected_appearance(self, size=None, shape=None, color=None):
        if not self.selected_bones:
            return

        from ..backend import mirror_name

        # Build a lookup once instead of searching every time
        items = {item["bone_name"]: item for item in self.data["items"]}

        for item in self.data["items"]:

            if item["bone_name"] not in self.selected_bones:
                continue

            # -----------------------------
            # Update selected control data
            # -----------------------------
            if size is not None:
                item["control_size"] = size

            if shape is not None:
                item["control_shape"] = shape

            if color is not None:
                item["control_color"] = color

            # -----------------------------
            # Update selected widget
            # -----------------------------
            widget = self.window.control_list.controls.get(item["bone_name"])

            if widget:
                widget.set_appearance(
                    size=size,
                    shape=shape,
                    color=color
                )

            # -----------------------------
            # Update mirrored control
            # -----------------------------
            mirror_bone = mirror_name(item["bone_name"])

            if mirror_bone:

                mirror_item = items.get(mirror_bone)

                if mirror_item:

                    if size is not None:
                        mirror_item["control_size"] = size

                    if shape is not None:
                        mirror_item["control_shape"] = shape

                    if color is not None:
                        mirror_item["control_color"] = color

                    mirror_widget = self.window.control_list.controls.get(
                        mirror_bone
                    )

                    if mirror_widget:
                        mirror_widget.set_appearance(
                            size=size,
                            shape=shape,
                            color=color
                        )

        # Update control positions once in case size changed
        self.window.control_list.container.layout_controls()
        self.save()

    def calculate_motion_path(self):
        if not self.selected_bones:
            return

        bpy.ops.rp.calculate_path()

    def clear_motion_path(self):
        if not self.selected_bones:
            return

        bpy.ops.rp.clear_path()

    def show_all(self):
        bpy.ops.rp.show_all()

    # ---------------------------------------------------------

    def hide_all(self):
        bpy.ops.rp.hide_all()

    def capture_view(self):
        if not self.armature_name:
            return

        bpy.ops.rp.capture_view()

        # RP_OT_CaptureView always renders to this fixed, shared temp path.
        temp_path = os.path.join(
            tempfile.gettempdir(),
            "rig_picker_capture.png"
        )

        if not os.path.exists(temp_path):
            return

        # Copy it into this armature's own dedicated image file so it can
        # never be overwritten by capturing a different armature's view.
        dest_path = json_manager.get_image_path(self.armature_name)

        import shutil
        shutil.copyfile(temp_path, dest_path)

        self.data["background"] = dest_path
        self.data["image_offset_x"] = 0.0
        self.data["image_offset_y"] = 0.0
        self.save()

        self.window.control_list.set_background(dest_path, 0.0, 0.0)

    def clear_all(self):
        self.data["items"] = []

        # Delete the captured background too, not just the controls -
        # both the JSON reference and the actual image file on disk, so
        # it doesn't linger and get silently picked back up later.
        image_path = self.data.get("background")

        self.data["background"] = ""
        self.data["image_offset_x"] = 0.0
        self.data["image_offset_y"] = 0.0

        self.save()

        if image_path:
            try:
                if os.path.exists(image_path):
                    os.remove(image_path)
            except OSError:
                import traceback
                traceback.print_exc()

        bpy.ops.rp.hide_all()
        self.refresh()

    def delete_selected(self):
        if not self.selected_bones:
            return

        selected = self.selected_bones

        self.data["items"] = [
            item for item in self.data["items"]
            if item["bone_name"] not in selected
        ]
        self.save()

        self.selected_bones.clear()

        self.window.size_combo.setEnabled(False)
        self.window.shape_combo.setEnabled(False)
        self.window.color_combo.setEnabled(False)

        # Force hiding remaining controls & update UI
        bpy.ops.rp.hide_all()
        self.refresh()

    def select_all(self):
        self.selected_bones = set(self.window.control_list.controls.keys())

        # Update UI widgets
        for name, widget in self.window.control_list.controls.items():
            widget.active = True
            widget.update()

        from ..backend import arm
        rig = arm()

        from ..backend import (
            get_3d_override,
            ensure_pose_mode,
        )

        if rig and rig.type == "ARMATURE":
            override = get_3d_override(bpy.context, rig)

            if override:
                with bpy.context.temp_override(**override):
                    ensure_pose_mode(bpy.context, rig)

                    bpy.ops.pose.reveal(select=False)
                    bpy.ops.pose.select_all(action="SELECT")

        # Update appearance control dropdowns
        if self.selected_bones:
            first = next(iter(self.selected_bones))
            item = self.find_item(first)

            if item:
                self.window.set_selected_control(
                    item["control_size"],
                    item["control_shape"],
                    item["control_color"],
                )

        self.refresh_ikfk_label()

    def deselect_all(self):
        self.selected_bones.clear()

        for widget in self.window.control_list.controls.values():
            widget.active = False
            widget.update()

        self.window.size_combo.setEnabled(False)
        self.window.shape_combo.setEnabled(False)
        self.window.color_combo.setEnabled(False)

        from ..backend import arm
        rig = arm()

        if rig and rig.type == 'ARMATURE':
            rig.data.bones.active = None

            # Use the same operator-backed approach as the Hide All button
            # (reveal -> deselect -> hide) instead of poking bone.hide
            # directly, so behavior/context-handling stays consistent.
            bpy.ops.rp.hide_all()

        self.refresh_ikfk_label()

    def toggle_symmetry(self, enabled):
        self.data["symmetry"] = enabled

        canvas = self.window.control_list.container
        canvas.symmetry_enabled = enabled

        if self.data.get("symmetry_x", -1.0) < 0:
            if canvas.background:
                self.data["symmetry_x"] = canvas.background.width() / 2

        canvas.symmetry_x = self.data["symmetry_x"]
        canvas.update()

    def toggle_ik_fk_setting(self, enabled):
        """Persists the IK-FK checkbox state and shows/hides the IK/FK
        switch plus its two snapping buttons (FK->IK, IK->FK) on the
        canvas accordingly."""
        self.data["ik_fk_enabled"] = enabled

        canvas = self.window.control_list.container
        canvas.ikfk_controls_enabled = enabled
        canvas.update_overlay_buttons()

    def toggle_motion_paths_setting(self, enabled):
        """Persists the Motion Paths checkbox state and shows/hides the
        Calculate/Clear motion-path buttons on the canvas accordingly."""
        self.data["motion_paths_enabled"] = enabled

        canvas = self.window.control_list.container
        canvas.motion_paths_controls_enabled = enabled
        canvas.update_overlay_buttons()

        self.save()
    def toggle_ik_fk(self):

        if len(self.selected_bones) != 1:
            return

        selected_bone = next(iter(self.selected_bones))

        parent_bone = None

        for parent, group in IK_FK_GROUPS.items():

            if (
                selected_bone == parent
                or selected_bone in group["output_bones"]
                or selected_bone in group["input_bones"]
                or selected_bone in group["ctrl_bones"]
            ):
                parent_bone = parent
                break

        if parent_bone is None:
            return

        rig = backend.arm()
        if rig is None:
            return

        pb = rig.pose.bones.get(parent_bone)
        if pb is None or "IK_FK" not in pb:
            return

        current = float(pb["IK_FK"])
        pb["IK_FK"] = 0.0 if current >= 0.5 else 1.0

        pb.keyframe_insert(
            data_path='["IK_FK"]',
            frame=bpy.context.scene.frame_current
        )

        rig.update_tag(refresh={'DATA'})
        bpy.context.view_layer.update()

        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()

        self.refresh_ikfk_label()
    

    def fk_to_ik(self):

        if len(self.selected_bones) != 1:
            return

        selected_bone = next(iter(self.selected_bones))

        parent_bone = None
        group = None

        for parent, data in IK_FK_GROUPS.items():
            if (
                selected_bone == parent
                or selected_bone in data["output_bones"]
                or selected_bone in data["input_bones"]
                or selected_bone in data["ctrl_bones"]
            ):
                parent_bone = parent
                group = data
                break

        if group is None:
            return

        rig = backend.arm()

        bpy.context.view_layer.objects.active = rig
        rig.select_set(True)

        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type != "VIEW_3D":
                    continue

                for region in area.regions:
                    if region.type != "WINDOW":
                        continue

                    with bpy.context.temp_override(
                        window=window,
                        area=area,
                        region=region,
                        active_object=rig,
                        object=rig,
                    ):

                        bpy.ops.pose.rigify_generic_snap_oeujyfjmc8c1f286(
                            output_bones=str(group["output_bones"]).replace("'", '"'),
                            input_bones=str(group["input_bones"]).replace("'", '"'),
                            ctrl_bones=str(group["ctrl_bones"]).replace("'", '"'),
                            tooltip="FK to IK",
                            locks=(False, False, False),
                        )

                        bpy.context.view_layer.update()

                        for win in bpy.context.window_manager.windows:
                            for ar in win.screen.areas:
                                ar.tag_redraw()

                        self.refresh_ikfk_label()
                        return


    def ik_to_fk(self):

        if len(self.selected_bones) != 1:
            return

        selected_bone = next(iter(self.selected_bones))

        parent_bone = None
        group = None

        for parent, data in IK_FK_GROUPS.items():
            if (
                selected_bone == parent
                or selected_bone in data["output_bones"]
                or selected_bone in data["input_bones"]
                or selected_bone in data["ctrl_bones"]
            ):
                parent_bone = parent
                group = data
                break

        if group is None:
            return

        rig = backend.arm()

        bpy.context.view_layer.objects.active = rig
        rig.select_set(True)

        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type != "VIEW_3D":
                    continue

                for region in area.regions:
                    if region.type != "WINDOW":
                        continue

                    with bpy.context.temp_override(
                        window=window,
                        area=area,
                        region=region,
                        active_object=rig,
                        object=rig,
                    ):

                        bpy.ops.pose.rigify_limb_ik2fk_oeujyfjmc8c1f286(
                            prop_bone=parent_bone,
                            pole_prop="pole_vector",

                            fk_bones=str(group["output_bones"]).replace("'", '"'),
                            ik_bones=str(group["input_bones"]).replace("'", '"'),
                            ctrl_bones=str(group["ctrl_bones"]).replace("'", '"'),

                            tail_bones=str(group.get("tail_bones", [])).replace("'", '"'),
                            extra_ctrls=str(group.get("extra_ctrls", [])).replace("'", '"'),
                        )

                        bpy.context.view_layer.update()

                        for win in bpy.context.window_manager.windows:
                            for ar in win.screen.areas:
                                ar.tag_redraw()

                        self.refresh_ikfk_label()
                        return